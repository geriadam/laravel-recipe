<footer class="footer">
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<p>Created by<a href="https://geriadam.github.com" class="text-dark" target="_blank">Gdev</a> © <?php echo e(\Date::now()->format('Y')); ?></p>
		</div>
	</div>
</footer><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\layouts\footer.blade.php ENDPATH**/ ?>