<nav class="navbar navbar-expand-xl navbar-light fixed-top hk-navbar">
    <a id="navbar_toggle_btn" class="navbar-toggle-btn nav-link-hover" href="javascript:void(0);">
        <span class="feather-icon"><i data-feather="menu"></i></span>
    </a>
</nav>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\layouts\navbar.blade.php ENDPATH**/ ?>