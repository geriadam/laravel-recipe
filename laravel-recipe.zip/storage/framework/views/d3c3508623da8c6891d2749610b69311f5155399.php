<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>Resep Makanan - Gdev</title>

<!-- Favicon -->
<link rel="shortcut icon" href="#">
<link rel="icon" href="#" type="image/x-icon">

<!-- Bootstrap -->
<link href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Owl Carousel -->
<link href="<?php echo e(asset('vendors/owl.carousel/dist/assets/owl.carousel.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('vendors/owl.carousel/dist/assets/owl.theme.default.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Dropzone -->
<link href="<?php echo e(asset('vendors/dropzone/dist/dropzone.css')); ?>" rel="stylesheet" type="text/css"/>

<!-- Toastr -->
<link href="<?php echo e(asset('vendors/jquery-toast-plugin/dist/jquery.toast.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Select2 -->
<link href="<?php echo e(asset('vendors/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Date Picker -->
<link href="<?php echo e(asset('vendors/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('vendors/datetimepicker/datetimepicker.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('vendors/datepicker/datepicker3.css')); ?>" rel="stylesheet" type="text/css">

<!-- Sweet Alert-->
<link href="<?php echo e(asset('vendors/sweetalert/sweetalert.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Custom -->
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css">

<!-- Color Picker -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.3/css/bootstrap-colorpicker.min.css" rel="stylesheet">
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\layouts\head.blade.php ENDPATH**/ ?>