<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" style="color: black">
                <div class="card-header"><?php echo e($recipe->title); ?></div>
                <div class="card-body">
                    <img src="<?php echo e(url($recipe->image_url)); ?>" width="100%" height="auto"> <br> <br>
                    Category : <?php echo e($recipe->category->name); ?> <br>
                    Time Estimation : <?php echo e($recipe->time); ?> <br> <br>
                    <?php echo $recipe->description; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\frontend\favorite\show.blade.php ENDPATH**/ ?>