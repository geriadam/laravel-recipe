<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title>Login</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo-agro.svg')); ?>">
    <link rel="icon" href="<?php echo e(asset('img/logo-agro.svg')); ?>" type="image/x-icon">

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>

    <!-- Owl Carousel -->
    <link href="<?php echo e(asset('vendors/owl.carousel/dist/assets/owl.carousel.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('vendors/owl.carousel/dist/assets/owl.theme.default.min.css')); ?>" rel="stylesheet"
          type="text/css"/>

    <!-- Toggles CSS -->
    <link href="<?php echo e(asset('vendors/jquery-toggles/css/toggles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendors/jquery-toggles/css/themes/toggles-light.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>
<body>
<!-- Preloader -->
<div class="preloader-it">
    <div class="loader-pendulums"></div>
</div>
<!-- /Preloader -->

<!-- HK Wrapper -->
<div class="hk-wrapper" id="quick_login">

    <!-- Main Content -->
    <div class="hk-pg-wrapper hk-auth-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12 pa-0">
                    <div class="auth-form-wrap pt-xl-0 pt-70">
                        <div class="auth-form w-xl-30 w-lg-55 w-sm-75 w-100">
                            <a class="auth-brand text-center d-block mb-20" href="#">
                                Login
                            </a>
                            <form method="POST" action="<?php echo e(route('login')); ?>" id="login_form">
                                <?php echo csrf_field(); ?>
                                <p class="text-center mb-30">Resep Makanan</p>

                                <div class="form-group">
                                    <input id="email" type="email"
                                           class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                           value="<?php echo e(old('email')); ?>" placeholder="Email" required autocomplete="email"
                                           autofocus v-model="username">

                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>

                                <div class="form-group">
                                    <div class="input-group">
                                        <input id="password" type="password"
                                               class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                               name="password" placeholder="Password" required
                                               autocomplete="current-password" v-model="password">

                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        <div class="input-group-append">
                                            <span class="input-group-text"><span class="feather-icon"><i
                                                        data-feather="eye-off"></i></span></span>
                                        </div>
                                    </div>
                                </div>

                                <button class="btn btn-primary btn-block" type="submit" id="login_button">Login</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <quick-login :accounts="accounts"></quick-login>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Main Content -->

</div>
<!-- /HK Wrapper -->

<!-- JavaScript -->

<!-- jQuery -->
<script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>

<!-- FeatherIcons JavaScript -->
<script src="<?php echo e(asset('js/feather.min.js')); ?>"></script>

<!-- Init JavaScript -->
<script src="<?php echo e(asset('js/init.js')); ?>"></script>

<?php echo $__env->yieldPushContent('before_scripts'); ?>

<script src="<?php echo e(url('/js/adminlte.min.js')); ?>"></script>
<script>
    var accounts = [
        {
            role: 'Super Admin',
            username: 'admin@admin.com',
            password: 'admin123'
        },
    ];
</script>

<script src="<?php echo e(asset('js/quick-login.js')); ?>"></script>

<?php echo $__env->yieldPushContent('after_scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\auth\login.blade.php ENDPATH**/ ?>