<div class="tile">
    <?php echo e(Form::open(['route' => ['backend.master.setting.store'], 'files' => true])); ?>

        <h3 class="tile-title">Social Media</h3>
        <hr>
        <?php echo Form::hidden('id', $setting->id ?? null); ?>

        <div class="tile-body">
            <div class="form-group">
                <label class="control-label" for="facebook_url">Facebook</label>
                <?php echo Form::text('facebook_url', $setting->facebook_url ?? null, ["class" => "form-control", "placeholder" => "http://facebook.com"]); ?>

            </div>
            <div class="form-group">
                <label class="control-label" for="twitter_url">Twitter</label>
                <?php echo Form::text('twitter_url', $setting->twitter_url ?? null, ["class" => "form-control", "placeholder" => "http://twitter.com"]); ?>

            </div>
            <div class="form-group">
                <label class="control-label" for="instagram_url">Instagram</label>
                <?php echo Form::text('instagram_url', $setting->instagram_url ?? null, ["class" => "form-control", "placeholder" => "http://instagram.com"]); ?>

            </div>
        </div>
        <div class="tile-footer">
            <div class="row d-print-none mt-2">
                <div class="col-12 text-right">
                    <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
                </div>
            </div>
        </div>
    <?php echo Form::close(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\master\setting\include\social_links.blade.php ENDPATH**/ ?>