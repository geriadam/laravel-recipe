<?php $__env->startSection('content'); ?>
<section class="category-page-wrap padding-top-80 padding-bottom-50">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="category-box-layout1">
                        <figure class="item-figure"><a href="<?php echo e(route('frontend.recipe.category', ['slug' => $category->slug])); ?>"><img src="<?php echo e(asset($category->image_url)); ?>" alt="Product"></a></figure>
                        <div class="item-content">
                            <h3 class="item-title"><a href="<?php echo e(route('frontend.recipe.category', ['slug' => $category->slug])); ?>"><?php echo e($category->name); ?></a></h3>
                            <span class="sub-title"> <?php echo e($category->recipe->count()); ?> Recipes</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\frontend\category.blade.php ENDPATH**/ ?>