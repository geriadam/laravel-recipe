<div class="tile">
    <?php echo e(Form::open(['route' => ['backend.master.setting.store'], 'files' => true])); ?>

        <h3 class="tile-title">Logo Website</h3>
        <hr>
        <?php echo Form::hidden('id', $setting->id ?? null); ?>

        <div class="tile-body">
            <div class="form-group">
                <label class="control-label" for="logo">Site Logo</label>
                <br>
                <?php if(isset($setting->logo) && $setting->logo != null): ?>
                    <img src="<?php echo e(asset($setting->logo_url)); ?>" id="logoImg" style="width: 80px; height: auto;">
                <?php else: ?>
                    <img src="https://via.placeholder.com/80x80?text=Placeholder+Image" id="logoImg" style="width: 80px; height: auto;">
                <?php endif; ?>
                <br>
                <?php echo Form::file('file_logo', null, ["class" => "form-control"]); ?>

            </div>
            <div class="form-group">
                <label class="control-label" for="favicon">Site Favicon</label>
                <br>
                <?php if(isset($setting->favicon) && $setting->favicon != null): ?>
                    <img src="<?php echo e(asset($setting->favicon_url)); ?>" id="logoImg" style="width: 80px; height: auto;">
                <?php else: ?>
                    <img src="https://via.placeholder.com/80x80?text=Placeholder+Image" id="logoImg" style="width: 80px; height: auto;">
                <?php endif; ?>
                <br>
                <?php echo Form::file('file_favicon', null, ["class" => "form-control"]); ?>

            </div>
        </div>
        <div class="tile-footer">
            <div class="row d-print-none mt-2">
                <div class="col-12 text-right">
                    <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
                </div>
            </div>
        </div>
    <?php echo Form::close(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\master\setting\include\logo.blade.php ENDPATH**/ ?>