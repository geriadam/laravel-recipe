<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <a href="<?php echo e(route('frontend.recipe.show', $favorite->recipe->slug)); ?>" style="text-decoration: none;">
                    <div class="card" style="color: black">
                        <div class="card-header"><?php echo e($favorite->recipe->title); ?></div>
                        <div class="card-body">
                            <img src="<?php echo e(url($favorite->recipe->image_url)); ?>" width="100%" height="auto"> <br> <br>
                            Category : <?php echo e($favorite->recipe->category->name); ?> <br>
                            Time Estimation : <?php echo e($favorite->recipe->time); ?>


                        </div>
                        <div class="card-footer">
                            <?php if(\Auth::check()): ?>
                                <a href="<?php echo e(route('frontend.favorite.recipe.destroy', $favorite)); ?>" style="text-decoration: none;">Delete</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($favorites->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\frontend\favorite\index.blade.php ENDPATH**/ ?>