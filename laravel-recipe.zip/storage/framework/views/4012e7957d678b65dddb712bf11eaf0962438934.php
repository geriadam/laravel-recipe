<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-4 col-sm-6">
        <div class="card card-sm">
            <div class="card-body">
                <span class="d-block font-11 font-weight-500 text-dark text-uppercase mb-10">Category</span>
                <div class="d-flex align-items-center justify-content-between position-relative">
                    <div>
                        <span class="d-block display-5 font-weight-400 text-dark"><?php echo e($category_count); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-sm-6">
        <div class="card card-sm">
            <div class="card-body">
                <span class="d-block font-11 font-weight-500 text-dark text-uppercase mb-10">Recipe</span>
                <div class="d-flex align-items-center justify-content-between position-relative">
                    <div>
                        <span class="d-block display-5 font-weight-400 text-dark"><?php echo e($recipe_count); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\beranda\home.blade.php ENDPATH**/ ?>