<?php $__env->startSection('content'); ?>
<section class="recipe-without-sidebar-wrap padding-top-80 padding-bottom-22">
    <div class="container">
        <?php echo e(Form::open(['route' => 'frontend.recipe.index', 'method' => 'GET'])); ?>

            <div class="adv-search-wrap">
                <div class="input-group">
                    <input name="title" type="text" class="form-control" placeholder="Recipe Search . . ." value="<?php echo e(old('title')); ?>" />
                    <div class="btn-group">
                        <div class="input-group-btn">
                            <button type="submit" class="btn-search"><i class="flaticon-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        <?php echo Form::close(); ?>

        <div class="row">
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="product-box-layout1">
                        <figure class="item-figure"><a href="single-recipe1.html"><img src="<?php echo e(asset($recipe->image_url)); ?>" alt="Product"></a></figure>
                        <div class="item-content">
                            <span class="sub-title"><?php echo e($recipe->category->name); ?></span>
                            <h3 class="item-title"><a href="<?php echo e(route('frontend.recipe.show', ["slug" => $recipe->slug])); ?>"><?php echo e($recipe->title); ?></a></h3>
                            <?php echo \Str::words($recipe->description, 18,'....'); ?>

                            <ul class="entry-meta">
                                <li><a href="#"><i class="fas fa-clock"></i><?php echo e($recipe->cooking_time); ?></a></li>
                                <li><a href="#"><i class="fas fa-user"></i>by <span><?php echo e($recipe->user->name); ?></span></a></li>
                                <li><a href="#"><i class="fas fa-heart"></i><?php echo e(ucfirst($recipe->difficulty)); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\frontend\recipe\index.blade.php ENDPATH**/ ?>