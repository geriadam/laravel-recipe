<!-- Jquery Js -->
<script src="<?php echo e(asset('frontend/js/jquery-3.3.1.min.js')); ?>"></script>
<!-- Bootstrap Js -->
<script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
<!-- Bootstrap Js -->
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<!-- Plugins Js -->
<script src="<?php echo e(asset('frontend/js/plugins.js')); ?>"></script>
<!-- Owl Carousel Js -->
<script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
<!-- Smoothscroll Js -->
<script src="<?php echo e(asset('frontend/js/smoothscroll.min.js')); ?>"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\includes\js.blade.php ENDPATH**/ ?>