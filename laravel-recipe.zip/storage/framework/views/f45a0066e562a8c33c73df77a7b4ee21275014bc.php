<link rel="shortcut icon" href="<?php echo e(asset('frontend/img/favicon.png')); ?>">
<!-- Normalize Css -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/normalize.css')); ?>">
<!-- Main Css -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/main.css')); ?>">
<!-- Bootstrap Css -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>">
<!-- Animate CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/animate.min.css')); ?>">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/fontawesome-all.min.css')); ?>">
<!-- Flaticon CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/fonts/flaticon.css')); ?>">
<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.theme.default.min.css')); ?>">
<!-- Custom Css -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/style.css')); ?>">
<!-- Modernizr Js -->
<script src="<?php echo e(asset('js/modernizr-3.6.0.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\includes\css.blade.php ENDPATH**/ ?>