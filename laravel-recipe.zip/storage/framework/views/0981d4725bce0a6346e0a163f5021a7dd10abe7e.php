<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('backend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->yieldPushContent('after_styles'); ?>
</head>

<body>
<div class="preloader-it">
    <div class="loader-pendulums"></div>
</div>

<div class="hk-wrapper hk-vertical-nav">

    <!-- Top Navbar --><?php echo $__env->make('backend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!-- /Top Navbar -->

    <!-- Vertical Nav --><?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!-- /Vertical Nav -->

    <!-- Main Content -->
    <div class="hk-pg-wrapper">

        <nav class="hk-breadcrumb" aria-label="breadcrumb">
            <?php echo e(Breadcrumbs::render()); ?>

        </nav>

        <div class="mt-xl-20 mt-sm-20 mt-15">
            <?php echo $__env->make('backend.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="hk-footer-wrap container-fluid">
            <?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>
    <!-- /Main Content -->

</div>

<?php echo $__env->make('backend.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('after_scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\layouts\app.blade.php ENDPATH**/ ?>