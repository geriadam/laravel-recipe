<?php $__env->startSection('content'); ?>
    <div class="hk-pg-header">
        <h4 class="hk-pg-title"><span class="pg-title-icon"><i class="fa fa-users"></i></span></span>Setting</h4>
    </div>

    <section class="hk-sec-wrapper">
        <div class="row">
            <div class="col-md-3">
                <ul class="nav flex-column nav-tabs user-tabs">
                    <li class="nav-item"><a class="nav-link active" href="#general" data-toggle="tab">General</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact" data-toggle="tab">Kontak</a></li>
                    <li class="nav-item"><a class="nav-link" href="#site-logo" data-toggle="tab">Logo Website</a></li>
                    <li class="nav-item"><a class="nav-link" href="#social-links" data-toggle="tab">Social Media</a></li>
                </ul>
            </div>
            <div class="col-md-9">
                <div class="tab-content">
                    <div class="tab-pane active" id="general">
                        <?php echo $__env->make('backend.master.setting.include.general', ['setting' => $setting], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane" id="contact">
                        <?php echo $__env->make('backend.master.setting.include.contact', ['setting' => $setting], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane fade" id="site-logo">
                        <?php echo $__env->make('backend.master.setting.include.logo', ['setting' => $setting], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane fade" id="social-links">
                        <?php echo $__env->make('backend.master.setting.include.social_links', ['setting' => $setting], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\master\setting\index.blade.php ENDPATH**/ ?>