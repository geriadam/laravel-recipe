<?php $__env->startSection('content'); ?>
    <div class="hk-pg-header">
        <h4 class="hk-pg-title">
            <span class="pg-title-icon"><i class="fa fa-stethoscope"></i></span> Create Page
        </h4>
    </div>

    <section class="hk-sec-wrapper">
        <div class="row">
            <div class="col-sm">
                <?php echo e(Form::open(['route' => ['backend.master.page.store']])); ?>

                <div class="form-group">
                    <label>Title<span class="text-danger">*</span></label>
                    <?php echo Form::text('title', null, ["class" => "form-control"]); ?>

                </div>
                <div class="form-group">
                    <label>Description<span class="text-danger">*</span></label>
                    <?php echo Form::textarea('description', null, ["class" => "form-control"]); ?>

                </div>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <a href="<?php echo e(route('backend.master.page.index')); ?>" class="btn btn-secondary btn-rounded">Cancel</a>
                        <button class="btn btn-primary btn-rounded" type="submit">Save</button>
                    </div>
                    <div class="col-sm-6">
                        <span class="pull-right"><span class="text-danger">*</span>required</span>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kuliah\laravel-recipe\resources\views\backend\master\page\create.blade.php ENDPATH**/ ?>