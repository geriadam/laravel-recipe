/*Gallery Init*/

"use strict";

/***** LightGallery init start*****/	
$('.hk-gallery').lightGallery({  showThumbByDefault: false,hash: false});
/***** LightGallery init end*****/
