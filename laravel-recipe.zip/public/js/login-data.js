/*Login Init*/
 
"use strict"; 
$('#owl_demo_1').owlCarousel({
	items: 1,
	animateOut: 'fadeOut',
	loop: true,
	margin: 10,
	autoplay: true,
	mouseDrag: false

});
