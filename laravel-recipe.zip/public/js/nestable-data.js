/*Nestable Init*/
$( document ).ready(function() {
	"use strict";
	
	/*Nestable*/
	$('#nestable').nestable({group: 1});
	$('#nestable2').nestable({group: 1});

});