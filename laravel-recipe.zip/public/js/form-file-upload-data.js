/*FileUpload Init*/
"use strict";
/*Dropzone Init*/
$("#remove_link").dropzone({
	addRemoveLinks: true,
});
$(document).ready(function() {
	/* Basic Init*/
	$('.dropify').dropify();
	
});