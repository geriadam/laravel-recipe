/* Inputspinner Init*/  
"use strict";
$("input.normal").inputSpinner({buttonsClass: "btn-outline-light"});
$("input.float").inputSpinner({buttonsClass: "btn-light"});
$("input.small").inputSpinner({groupClass: "input-group-sm w-50",buttonsClass: "btn-outline-light"});
$("input.large").inputSpinner({groupClass: "input-group-lg",buttonsClass: "btn-light"});