/*Toggle Init*/
 
"use strict"; 
$('.toggle1').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: '', // text for the ON position
	off: '' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
$('.toggle2').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: 'ON', // text for the ON position
	off: 'OFF' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
$('.toggle3').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: 'ON', // text for the ON position
	off: 'OFF' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'select' // if this is set to 'select' then the select style toggle will be used
});
$('.toggle4').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: 'ON', // text for the ON position
	off: 'OFF' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
/*
$('#toggle_1').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: 'ON', // text for the ON position
	off: 'OFF' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
$('#toggle_2').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: '', // text for the ON position
	off: '' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
$('#toggle_3').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: '', // text for the ON position
	off: '' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
$('#toggle_4').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: '', // text for the ON position
	off: '' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'compact' // if this is set to 'select' then the select style toggle will be used
});
$('#toggle_5').toggles({
	drag: true, // allow dragging the toggle between positions
	click: true, // allow clicking on the toggle
	text: {
	on: 'YES', // text for the ON position
	off: 'NO' // and off
	},
	on: true, // is the toggle ON on init
	animate: 250, // animation time (ms)
	easing: 'swing', // animation transition easing function
	checkbox: null, // the checkbox to toggle (for use in forms)
	clicker: null, // element that can be clicked on to toggle. removes binding from the toggle itself (use nesting)
	
	type: 'select' // if this is set to 'select' then the select style toggle will be used
});*/