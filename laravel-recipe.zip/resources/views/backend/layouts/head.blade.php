<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>Resep Makanan - Gdev</title>

<!-- Favicon -->
<link rel="shortcut icon" href="#">
<link rel="icon" href="#" type="image/x-icon">

<!-- Bootstrap -->
<link href="{{ asset('vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">

<!-- Owl Carousel -->
<link href="{{ asset('vendors/owl.carousel/dist/assets/owl.carousel.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('vendors/owl.carousel/dist/assets/owl.theme.default.min.css') }}" rel="stylesheet" type="text/css">

<!-- Dropzone -->
<link href="{{ asset('vendors/dropzone/dist/dropzone.css') }}" rel="stylesheet" type="text/css"/>

<!-- Toastr -->
<link href="{{ asset('vendors/jquery-toast-plugin/dist/jquery.toast.min.css') }}" rel="stylesheet" type="text/css">

<!-- Select2 -->
<link href="{{ asset('vendors/select2/dist/css/select2.min.css') }}" rel="stylesheet" type="text/css">

<!-- Date Picker -->
<link href="{{ asset('vendors/daterangepicker/daterangepicker.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('vendors/datetimepicker/datetimepicker.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('vendors/datepicker/datepicker3.css') }}" rel="stylesheet" type="text/css">

<!-- Sweet Alert-->
<link href="{{ asset('vendors/sweetalert/sweetalert.min.css') }}" rel="stylesheet" type="text/css">

<!-- Custom -->
<link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('css/custom.css') }}" rel="stylesheet" type="text/css">

<!-- Color Picker -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.3/css/bootstrap-colorpicker.min.css" rel="stylesheet">
