<footer class="footer">
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<p>Created by<a href="https://geriadam.github.com" class="text-dark" target="_blank">Gdev</a> © {{ \Date::now()->format('Y') }}</p>
		</div>
	</div>
</footer>