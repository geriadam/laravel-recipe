<link rel="shortcut icon" href="{{ asset('frontend/img/favicon.png') }}">
<!-- Normalize Css -->
<link rel="stylesheet" href="{{ asset('frontend/css/normalize.css') }}">
<!-- Main Css -->
<link rel="stylesheet" href="{{ asset('frontend/css/main.css') }}">
<!-- Bootstrap Css -->
<link rel="stylesheet" href="{{ asset('frontend/css/bootstrap.min.css') }}">
<!-- Animate CSS -->
<link rel="stylesheet" href="{{ asset('frontend/css/animate.min.css') }}">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="{{ asset('frontend/css/fontawesome-all.min.css') }}">
<!-- Flaticon CSS -->
<link rel="stylesheet" href="{{ asset('frontend/fonts/flaticon.css') }}">
<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="{{ asset('frontend/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/css/owl.theme.default.min.css') }}">
<!-- Custom Css -->
<link rel="stylesheet" href="{{ asset('frontend/style.css') }}">
<!-- Modernizr Js -->
<script src="{{ asset('js/modernizr-3.6.0.min.js') }}"></script>
