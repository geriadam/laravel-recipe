<!-- Jquery Js -->
<script src="{{ asset('frontend/js/jquery-3.3.1.min.js') }}"></script>
<!-- Bootstrap Js -->
<script src="{{ asset('frontend/js/popper.min.js') }}"></script>
<!-- Bootstrap Js -->
<script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
<!-- Plugins Js -->
<script src="{{ asset('frontend/js/plugins.js') }}"></script>
<!-- Owl Carousel Js -->
<script src="{{ asset('frontend/js/owl.carousel.min.js') }}"></script>
<!-- Smoothscroll Js -->
<script src="{{ asset('frontend/js/smoothscroll.min.js') }}"></script>
<!-- Custom Js -->
<script src="{{ asset('frontend/js/main.js') }}"></script>
